import { useState, useEffect } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Container } from "@mui/material";
import { useSearchParams } from "react-router-dom";
import data from "../assets/data/events.json";
import ResponsiveDialog from "../Components/newsModal";

export default function Events(props) {
  const { loading = false } = props;
  const [openEvent, setOpenEvent] = useState(null);
  const [searchParams, setSearchParams] = useSearchParams();

  useEffect(() => {
    if (searchParams.get("name")) {
      setOpenEvent(
        data.find((event) => event.title === searchParams.get("name"))
      );
    }
  }, []);

  const handleCloseEvent = () => {
    setOpenEvent(null);
    setSearchParams("");
  };

  const handleOpenEvent = (item) => {
    setOpenEvent(data.find((event) => event.title === item.title));
    setSearchParams(`name=${item.title}`)
  }

  return (
    <Container sx={{ mt: "100px" }}>
      <Typography variant="h4" sx={{ color: "#ff3c00", pb: "40px" }}>
        OUR EVENTS
      </Typography>
      <Grid container spacing={4} sx={{ pb: "80px" }}>
        {(loading ? Array.from(new Array(3)) : data).map((item, index) => (
          <Grid item key={index} size={{ xs: 12, sm: 4 }}>
            <Box
              onClick={() => {
                handleOpenEvent(item)
              }}
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "flex-start",
                padding: "5px",
                cursor: "pointer",
                "&:hover": {
                  backgroundColor: "rgb(42, 41, 41)",
                },
              }}
            >
              <Box
                component="img"
                src={item.src}
                alt={item.title}
                sx={{
                  width: "100%",
                  height: 300,
                  objectFit: "cover",
                  borderRadius: 1,
                }}
              />
              <Typography
                variant="caption"
                sx={{ mt: 2, color: "#6C63FF", fontWeight: 600 }}
              >
                {item.createdAt.toUpperCase()}
              </Typography>
              <Typography variant="h6" sx={{ fontWeight: 700, mt: 1, mb: 2 }}>
                {item.title}
              </Typography>
              
            </Box>
          </Grid>
        ))}
      </Grid>
      {openEvent && (
        <ResponsiveDialog
          open={openEvent ? true : false}
          onClose={handleCloseEvent}
          title={openEvent.title}
          description={openEvent.channel}
          createdAt={openEvent.createdAt}
          img={openEvent.src}
        />
      )}
    </Container>
  );
}
