import * as React from "react";

function Biography() {
  return (
    <div>
      
    </div>
  )
}

export default Biography
