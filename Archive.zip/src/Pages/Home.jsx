import * as React from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import "./Home.css";
import { Typography } from "@mui/material";
import CountdownTimer from "../Components/CountdownTimer/CountdownTimer";
import image1 from "../Images/driver.png";
import News from "./../Components/News/NewsPreviw";



export default function FixedContainer() {
  return (
    <React.Fragment>
      <Container maxWidth>
        <Box
          className="name"
          sx={{
            bgcolor: "#0d0d0f",
            paddingBottom: "100px",
            position: "relative",
          }}
        >
          <Box sx={{maxHeight: "100vh - 100px"}}>
          <Box sx={{ position: "relative", zIndex: 2 }}>
            <h1>
              <span>UROŠ</span>
              <br />
              BRKIĆ
            </h1>
            <p className="acent">RACING DRIVER</p>

            <Box textAlign="center" mt={8} sx={{ width: "fit-content" }}>
              <Typography
                variant="h5"
                sx={{
                  color: "#ffffff",
                  letterSpacing: "5px",
                  textAlign: "left",
                  ml: "10px",
                }}
              >
                NEXT EVENT IN
              </Typography>
              <CountdownTimer targetDate="2025-06-10T15:00:00" />
            </Box>
          </Box>
          <img
            className="image1"
            src={image1}
            alt="Driver"
            style={{
              maxWidth: "480px",
              height: "auto",
              position: "absolute",
              right: "0px",
              top: "80px",
              zIndex: 1,
              opacity: 1,
            }}
          />
          </Box>
          <Box className="newsContainer" sx= {{mt: "80px"}}>
          <p className="acent" >LATEST NEWS</p>
          <News />
          </Box>
        </Box>
      </Container>
    </React.Fragment>
  );
}
