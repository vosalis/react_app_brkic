import { useState, useEffect, Fragment } from "react";
import {Dialog, DialogContent, DialogContentText, DialogTitle, Box} from "@mui/material";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";

export default function ResponsiveDialog({
  open,
  onClose,
  title,
  description,
  img,
  createdAt,
}) {
  const [openModal, setOpenModel] = useState(false);
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));

  useEffect(() => {
    if (open) {
      setOpenModel(true);
    }
  }, [open]);

  const handleClose = () => {
    setOpenModel(false);
    onClose();
  };

  return (
    <Fragment>
      <Dialog
        fullScreen={fullScreen}
        open={openModal}
        onClose={handleClose}
        aria-labelledby="responsive-dialog-title"
      >
        <Box
          component="img"
          src={img}
          alt={title}
          sx={{
            width: "100%",
            height: 300,
            objectFit: "cover",
            borderRadius: 1,
          }}
        />
        <DialogTitle id="responsive-dialog-title">
          {title} - {createdAt}
        </DialogTitle>
        <DialogContent>
          <DialogContentText>{description}</DialogContentText>
        </DialogContent>
      </Dialog>
    </Fragment>
  );
}
