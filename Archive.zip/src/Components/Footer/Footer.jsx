import * as React from "react";
import "./Footer.css";
import { styled } from "@mui/joy/styles";
import Sheet from "@mui/joy/Sheet";
import Box from "@mui/material/Box";
import Grid from "@mui/joy/Grid";
import Paper from "@mui/material/Paper";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";

import FacebookIcon from "@mui/icons-material/Facebook";
import YouTubeIcon from "@mui/icons-material/YouTube";
import InstagramIcon from "@mui/icons-material/Instagram";
import TwitterIcon from "@mui/icons-material/Instagram";

const Item = styled(Sheet)(({ theme }) => ({
  backgroundColor: "#222222",
  ...theme.typography["body-sm"],
  padding: theme.spacing(1),
  textAlign: "center",
  borderRadius: 4,
  color: theme.vars.palette.text.secondary,
  ...theme.applyStyles("dark", {
    backgroundColor: theme.palette.background.level1,
  }),
}));

export default function AutoGrid() {
  return (
    <Paper
      component="footer"
      square
      variant="outlined"
      sx={{
        width: "100%",
        mt: 4, // small margin top
        py: 3, // padding top and bottom
        backgroundColor: "#222222",
        margin: "0"
      }}
    >
      <Container maxWidth="lg">
        <Box
          sx={{
            flexGrow: 1,
            justifyContent: "center",
            display: "flex",
            my: 1,
            textDecoration: "none"
          }}
        >
          <Grid  container spacing={3} sx={{ flexGrow: 1 }}>
            <Grid md={3} xs={8}>
              <Typography variant="h6">ABOUT MILOS</Typography>
              <Typography>
                Professional racing driver, multiple European and World Champion and professional racing coach
              </Typography>
            </Grid>
            <Grid  md={2} xs={8} >
              <Typography variant="h6" >SERVICES</Typography>
              <ul >
                <li><a href="#">coaching</a></li>
                <li><a href="#">training</a></li>
              </ul>
            </Grid>
            <Grid  md={3} xs={8}>
              <Typography variant="h6">COOKIE AND PRIVACY POLICY</Typography>
              <Typography>
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
              </Typography>
            </Grid>
            <Grid  sx={{ display: "flex", /*justifyContent: "flex-end",  alignItems: "center",*/ color: "#fffef6",paddingTop:"30px"}} md={3} xs={8}>
              <FacebookIcon sx={{ mx: 1 }} />
              <YouTubeIcon sx={{ mx: 1 }} />
              <InstagramIcon sx={{ mx: 1 }} />
              <TwitterIcon sx={{ mx: 1 }} />
            </Grid>
          </Grid>
        </Box>
      </Container>
    </Paper>
  );
}
