import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import ResponsiveAppBar from './Components/Nav/Navbar';
import GuestFooter from './Components/Footer/Footer';
import { Box, Container } from '@mui/material';
import Gallery from './Pages/Gallery';
import Home from './Pages/Home';
import Events from './Pages/Events';
import Biography from './Pages/Biography/Biography';
import './App.css';


function App() {
  return (
    <BrowserRouter>
      <Box
        sx={{
          bgcolor: '#000000',
          display: 'flex',
          flexDirection: 'column',
          minHeight: '100vh', // full height viewport
        }}
      >
        <ResponsiveAppBar />
        
        <Container sx={{ flex: 1, mt: 2, marginTop: "0" }}>
          <Routes>
            
            <Route path="/"  element={<Home />} />
            <Route path="/home" element={<Home />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/biography" element={<Biography />} />
            <Route path="/events" element={<Events />} />
          </Routes>
        </Container>

        <GuestFooter />
      </Box>
    </BrowserRouter>
  );
}

export default App;
